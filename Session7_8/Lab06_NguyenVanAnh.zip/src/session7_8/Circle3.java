/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session7_8;

/**
 *
 * @author asus
 */
public class Circle3 {
    private double PI=3.14;
    public double calcArea(double rad){
    return (3.14 * rad * rad);
    }
        /**
    * Trả về diện tích hình tròn
    *
    * @param rad một biến chỉ ra bán kính hình tròn
    * @return diện tích của vòng tròn
    * @ xem PI
    **/
}
