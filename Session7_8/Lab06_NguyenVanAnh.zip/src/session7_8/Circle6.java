/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session7_8;

/**
 *
 * @author asus
 */
public class Circle6 {
    private float rad; // Variable to store radius of a circle
    private float PI; // Variable to store value of PI
    /**
    * No-argument constructor
    *
    */
    public Circle6(){
    PI = 3.14f;
    }
    /**
    * Overloaded constructor
    *
    * @param r a float variable to store the value of radius
    */
    public Circle6(float r) {
    this(); // Invoke the no-argument constructor
    rad = r;
    }
    public static void main(String[] args) {
        
    }
}
