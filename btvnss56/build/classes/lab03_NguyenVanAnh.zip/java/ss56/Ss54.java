/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btvnss56;

/**
 *
 * @author asus
 */
public class Ss54 {
    public static void main(String[] args) {
            int num = 1, sum = 0;
            do {
            sum = sum + num;
            num++;
            } while (num <= 10);

            // Prints the value of variable after the loop terminates
            System.out.printf("Sum of 10 Numbers: %d\n", sum);
    
    }
}
