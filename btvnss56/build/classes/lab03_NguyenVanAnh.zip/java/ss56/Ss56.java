/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btvnss56;

/**
 *
 * @author asus
 */
public class Ss56 {
    public static void main(String[] args) {
        int i, j;
        int max = 10;
        for (i = 0, j = max; i <= max; i++, j--) {
        System.out.printf("\n%d + %d = %d", i, j, i + j);
        }
    }
}
